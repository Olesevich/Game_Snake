import javax.swing.*;

public class StartWindows extends JFrame {

    public StartWindows(){
        setTitle("Змейка");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setSize(370,390);
        setLocation(400,400);
        setResizable(false);
        setLocationRelativeTo(null);
        add(new StartWin());
        setVisible(true);
    }

}
