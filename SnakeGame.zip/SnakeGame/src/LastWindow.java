import javax.swing.*;

public class LastWindow extends JFrame {

    public LastWindow(){
        setTitle("Змейка");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setSize(370,390);
        setLocation(400,400);
        setResizable(false);
        setLocationRelativeTo(null);
        add(new LastWin());
        setVisible(true);
    }
}
