import javax.swing.*;

public class MainWindows extends JFrame {

    public MainWindows(){
        setTitle("Змейка");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setSize(370,390);
        setLocation(400,400);
        setResizable(false);
        setLocationRelativeTo(null);
        add(new GameField());
        setVisible(true);
    }

    public static void main(String[] args) {
        StartWindows sw = new StartWindows();

    }
}
